function myBirthYearFunc(){
    console.log("I was born in " + 1980);
    }
    // the screen will display i was born in 1980



function myBirthYearFunc(birthYearInput){
            console.log("I was born in " + birthYearInput);
        }

    // the screen will display i was born in (the content of tge variable birthyearinput)
    // if the variable birthYearInput is 1994 the screen will display i was born in 1994
       

function add(num1, num2){    //if num1=10 & num2=20
                console.log("Summing Numbers!"); //the screen will display summing numbers!
                console.log("num1 is: " + num1); // the screen will display num1 is 10
                console.log("num2 is: " + num2);// the screen will display num1 is 20
                var sum = num1 + num2;              // sum=10+20

                console.log(sum);                  // the screen wil display 30 
            }
            


