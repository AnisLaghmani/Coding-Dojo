var ChildHeight1=50;
var ChildHeight2=54;
function DisplayIfChildIsAbleToRideTheRollerCoaster(num) {
    if (num>52) {console.log("Get on that ride, kiddo!")}
    else {console.log("Sorry kiddo. Maybe next year.")}};


    DisplayIfChildIsAbleToRideTheRollerCoaster(ChildHeight1);
    DisplayIfChildIsAbleToRideTheRollerCoaster(ChildHeight2);
